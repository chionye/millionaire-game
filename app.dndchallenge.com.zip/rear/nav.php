<nav class="transparent z-depth-0">

    <div class="nav-wrapper container">

      <h1><a href="index.php" class="brand-logo"><img src="<?php echo $px = !empty($company_logo_ref)? $company_logo_ref : "images/logo.png" ?>" /> <?php echo strtoupper($company_name); ?></a></h1>

      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>

      <ul class="hide-on-med-and-down side_margin logo_li">

        

      </ul>

      <a id="login" class="grey-text text-lighten-2 right" href="login.php">Log In</a>

      <a class="waves-effect waves-light btn-large right blue darken-2 top_margin upper">Get Started</a>

      

    </div>

  </nav>