<?php

	$_exception=1;

	require_once "../database/connect.php";

	require_once "create_setup_table.php";

?>