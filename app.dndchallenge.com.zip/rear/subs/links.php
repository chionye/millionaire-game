<?PHP 
$dir = "../rear/";
?>
<link rel="stylesheet" type="text/css" href="css/dashboard.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto|Inconsolata" rel="stylesheet"> 
<link href="<?= $dir ?>css/materialize.css" type="text/css" rel="stylesheet">
<link href="<?= $dir ?>css/form.css" rel="stylesheet" type="text/css" />
<link href="<?= $dir ?>css/uploadDialog_v2_0.css" rel="stylesheet" type="text/css" />
<link href="<?= $dir ?>css/index.css" rel="stylesheet" type="text/css" />
<link href="<?= $dir ?>css/default.css" rel="stylesheet" type="text/css" />
<link href="<?= $dir ?>css/material_icons.css" rel="stylesheet" type="text/css" />
<link href="<?= $dir ?>css/datetimepicker.css" rel="stylesheet" type="text/css" media="print" />
<link href="<?= $dir ?>css/generic_pictures.css" rel="stylesheet" type="text/css"/>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $px = !empty($company_logo_ref)? $company_logo_ref : "images/logo.png" ?>" />
<!--<script language="javascript" type="text/javascript" src="scripts/jquery-2.1.3.min.js"></script>
<script language="javascript" type="text/javascript" src="scripts/materialize.js"></script>
<script type="text/javascript" language="javascript" src="scripts/extensions.js"></script>
<script type="text/javascript" language="javascript" src="scripts/extensions.js"></script>
<script type="text/javascript" language="javascript" src="scripts/openform.js"></script>-->


  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">